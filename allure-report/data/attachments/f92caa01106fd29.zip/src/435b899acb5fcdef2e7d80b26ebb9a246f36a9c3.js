const {test,expect} = require('@playwright/test');

const BASE_URL = "https://eventhub.rahulshettyacademy.com";
const username = "sonal@yahoo.com";
const password = "Sonal@30";
const SIX_EVENTS_RESPONSE = {
  data: [
    { id: 1, title: 'Tech Summit 2025', category: 'Conference', eventDate: '2025-06-01T10:00:00.000Z', venue: 'HICC', city: 'Hyderabad', price: '999', totalSeats: 200, availableSeats: 150, imageUrl: null, isStatic: false },
    { id: 2, title: 'Rock Night Live',  category: 'Concert',    eventDate: '2025-06-05T18:00:00.000Z', venue: 'Palace Grounds', city: 'Bangalore', price: '1500', totalSeats: 500, availableSeats: 300, imageUrl: null, isStatic: false },
    { id: 3, title: 'IPL Finals',       category: 'Sports',     eventDate: '2025-06-10T19:30:00.000Z', venue: 'Chinnaswamy', city: 'Bangalore', price: '2000', totalSeats: 800, availableSeats: 50, imageUrl: null, isStatic: false },
    { id: 4, title: 'UX Design Workshop', category: 'Workshop', eventDate: '2025-06-15T09:00:00.000Z', venue: 'WeWork', city: 'Mumbai', price: '500', totalSeats: 50, availableSeats: 20, imageUrl: null, isStatic: false },
    { id: 5, title: 'Lollapalooza India', category: 'Festival', eventDate: '2025-06-20T12:00:00.000Z', venue: 'Mahalaxmi Racecourse', city: 'Mumbai', price: '3000', totalSeats: 5000, availableSeats: 2000, imageUrl: null, isStatic: false },
    { id: 6, title: 'AI & ML Expo',    category: 'Conference',  eventDate: '2025-06-25T10:00:00.000Z', venue: 'Bangalore International Exhibition Centre', city: 'Bangalore', price: '750', totalSeats: 300, availableSeats: 180, imageUrl: null, isStatic: false },
  ],
  pagination: { page: 1, totalPages: 1, total: 6, limit: 12 },
};
const FOUR_EVENTS_RESPONSE = {
  data: [
    { id: 1, title: 'Tech Summit 2025', category: 'Conference', eventDate: '2025-06-01T10:00:00.000Z', venue: 'HICC', city: 'Hyderabad', price: '999', totalSeats: 200, availableSeats: 150, imageUrl: null, isStatic: false },
    { id: 2, title: 'Rock Night Live',  category: 'Concert',    eventDate: '2025-06-05T18:00:00.000Z', venue: 'Palace Grounds', city: 'Bangalore', price: '1500', totalSeats: 500, availableSeats: 300, imageUrl: null, isStatic: false },
    { id: 3, title: 'IPL Finals',       category: 'Sports',     eventDate: '2025-06-10T19:30:00.000Z', venue: 'Chinnaswamy', city: 'Bangalore', price: '2000', totalSeats: 800, availableSeats: 50, imageUrl: null, isStatic: false },
    { id: 4, title: 'UX Design Workshop', category: 'Workshop', eventDate: '2025-06-15T09:00:00.000Z', venue: 'WeWork', city: 'Mumbai', price: '500', totalSeats: 50, availableSeats: 20, imageUrl: null, isStatic: false },
  ],
  pagination: { page: 1, totalPages: 1, total: 4, limit: 12 },
};

test.describe.configure({mode:'serial'});

async function loginAndGoToEvents(page,BASE_URL) {
   await page.goto(BASE_URL);
   await page.getByPlaceholder("you@email.com").fill(username)
   await page.getByLabel("Password").fill(password);
   await page.locator("#login-btn").click();
   await expect(page.getByText("Browse Events →")).toBeVisible();
   await page.locator("#nav-events").click();
   await expect(page.getByText("Upcoming Events")).toBeVisible();
}

async function setUpMockAPI(page,eventResponse) {
    page.route("**/api/events**", async(route)=> {
        const response= await page.request.fetch(route.request());
        await route.fulfill(
               {
                   response,
                   body: JSON.stringify(eventResponse),
                   contentType: "application/json",
                   status: 200
               }
             )
         }); 
    }


test("@Smoke 6 events",async({page})=> {
   await setUpMockAPI(page,SIX_EVENTS_RESPONSE);
   await loginAndGoToEvents(page,BASE_URL);
   const eventCards=page.locator("[data-testid='event-card']");
   await expect(eventCards.first()).toBeVisible();
   expect(await eventCards.count()).toEqual(6);
   const banner=page.getByText(/sandbox holds up to/i);
   await expect(banner).toBeVisible();
   await expect(banner).toContainText("9 bookings");
})

test("@Smoke 4 events",async({page})=> {
   await setUpMockAPI(page,FOUR_EVENTS_RESPONSE);
   await loginAndGoToEvents(page,BASE_URL);
   const eventCards=page.locator("[data-testid='event-card']");
   await expect(eventCards.first()).toBeVisible();
   expect(await eventCards.count()).toEqual(4);
   const banner=page.getByText(/sandbox holds up to/i);
   await expect(banner).not.toBeVisible();
})
